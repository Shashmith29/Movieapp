# Movie Discovery App

Learning React and ES6 by building a Movie Discovery App.

## Screens

- Home
- TV Shows
- Search
- Detail

## API verbs

- Now playing (Movie)
- Upcoming (Movie)
- Top Rated (TV, Movie)
- Popular (TV, Movie)
- Airing Today (TV)
- TV Show Detail
- Movie Detail
