import DetailContainer from "./DetailContainer";

export default DetailContainer;
